Implementation of upbit systems for the virtual trading
