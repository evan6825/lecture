const request = require('request')
const { v4: uuidv4 } = require('uuid'); //npm install uuidv4 --save
const sign = require('jsonwebtoken').sign
const crypto = require('crypto')
const queryEncode = require("querystring").encode

const access_key = "testevan6825"
const secret_key = "TEST_SECRET_KET"
const server_url = "http://ubuntu.securekim.com/"

async function getBalance(){
    const payload = {
        access_key: access_key,
        nonce: uuidv4(),
    }
    const token = sign(payload, secret_key)
    const options = {
        method: "GET",
        url: server_url + "/v1/accounts",
        headers: {Authorization: `Bearer ${token}`},
    }
    return new Promise(function(resolve, reject) {
        request(options, (error, response, body) => {
            if (error) reject();
            console.log(response.statusCode) 
            resolve(body)
        })
    });
}

//얼마너치살건지
async function API_buyImmediate(market, price){ 
    const body = {
        market: market,
        side: 'bid',
        volume: null,
        price: price.toString(),
        ord_type: 'price',
    }
    const query = queryEncode(body)
    const hash = crypto.createHash('sha512')
    const queryHash = hash.update(query, 'utf-8').digest('hex')
    const payload = {
        access_key: access_key,
        nonce: uuidv4(),
        query_hash: queryHash,
        query_hash_alg: 'SHA512',
    }
    const token = sign(payload, secret_key)
    const options = {
        method: "POST",
        url: server_url + "/v1/orders",
        headers: {Authorization: `Bearer ${token}`},
        json: body
    }
    return new Promise(function(resolve, reject) {
        request(options, (error, response, body) => {
            if (error) reject();
            console.log(response.statusCode) 
            resolve(body)
        })
    });
}

//몇개팔건지
async function API_sellImmediate(market, volume){
    const body = {
        market: market,
        side: 'ask',
        volume: volume.toString(),
        price: null,
        ord_type: 'market',
    }
    const query = queryEncode(body)
    const hash = crypto.createHash('sha512')
    const queryHash = hash.update(query, 'utf-8').digest('hex')
    const payload = {
        access_key: access_key,
        nonce: uuidv4(),
        query_hash: queryHash,
        query_hash_alg: 'SHA512',
    }
    const token = sign(payload, secret_key)
    const options = {
        method: "POST",
        url: server_url + "/v1/orders",
        headers: {Authorization: `Bearer ${token}`},
        json: body
    }
    return new Promise(function(resolve, reject) {
        request(options, (error, response, body) => {
            if (error) reject();
            console.log(response.statusCode) 
            resolve(body)
        })
    });
}
async function get(url){
    return new Promise(function(resolve, reject) {
        request(url, (error, response, body) => {
            if (error) reject();
            console.log(response.statusCode) 
            resolve(body)
        })
    });
}
const sleep = (ms) => { //sleep함수를 사용하기위한 기본값
    return new Promise(resolve=>{
        setTimeout(resolve,ms)
    })
}
volume = {}
async function main(){
    while(true){
        ////////////변동성돌파///////

        ret = await get("http://kali.securekim.com:3082/view"); // 사이트에서 정보 추출해서 가져와 ret에 보관
        // console.log(ret) // ret안에 정보를 찍어볼수 있다.
        retJSON = JSON.parse(ret); //ret 안에 정보값을 JSON파일로 변경하여 키 와 값으로 저장
        // console.log(retJSON)
        balance = await getBalance()  //get balnce
        for (var i in retJSON){ //for문을 통해서 retJSON[i] 배열안에 .rsiSignal 값을 rsiSignal에 저장
            market = i ;
            rsiSignal = retJSON[i].rsiSignal;
            //console.log(rsiSignal) // rsiSingal에 제대로 들어갔는지 확인
            if (rsiSignal == "BIGLONG" || rsiSignal == "BIGLONG"){ //rsiSignal의 값이 long이나 biglong인 애들만 갑을 저장
                // console.log("!!!!BUY!!!! MARKET : "+ market);
                body = await API_buyImmediate(market,50000); //(market : 코인 , 얼마치 구매를할지)
                console.log(body)
                if(typeof volume[market] == "undefined"){ //구매된 코인의 개수가 증가할때 
                    volume[market] = body.volume;
                    console.log(market+"이(가)"+body.volume+"개 구매되었습니다.")
                } else {
                    volume[market] += body.volume
                    console.log(market+"이(가)"+body.volume+"개 구매되어서. 총"+volume[market]+"개가 구매되었습니다.")
                }
            }
            else if (rsiSignal == "SHORT" || rsiSignal == "BIGSHORT"){ //판매하는식
                let volume;
                    for(var i in balance){
                        if("KRW-" + balance[i].currency == market){
                            volume = balance[i].balance;
                        }
                    }
                }
                if(volume > 0){
                await API_sellImmediate(market, volume[market]);
                }
                else{
                    console.log("토큰이 없습니다.")
                }
            }


            await sleep(3000)
         }
    
    //// ERROR TEST - BUY ////
    //body = await getBalance()
    // body = await API_buyImmediate("KRW-ETH", 2000000);   // 정상 구매 
    //
    //36609686
    //36604449
    //1.0138627037817458
    //1.014008084593923
    //348583.84272261686
    //353695.55995306565
    // body = await API_buyImmediate("KRW-ETH", 100000);   // 정상 구매
    // console.log(body);
    // body = await API_buyImmediate("KRW-BTC", 500000);   // 정상 구매
    // body = await API_sellImmediate("KRW-BTC", 1.0);     // 정상 판매
    // body = await API_buyImmediate("KRW-BTC", -1);       // 범위 에러
    // body = await API_buyImmediate("KRW-BTC", 1);        // 최소 에러
    // body = await API_buyImmediate("KRW-BTC", 5234);     // 단위 에러..안남
    // body = await API_buyImmediate("KRW-BTC", "");       // 가격 에러
    // body = await API_buyImmediate("KRW-BTC", 100000000);  // 가격 에러
    // body = await API_buyImmediate("KRW-ABC", 10000);    // 마켓 에러
    // body = await API_buyImmediate("", 10000);           // 마켓 에러
    // body = await API_buyImmediate("KRW-ABC-BTC", 10000);// 마켓 에러
    // body = await API_sellImmediate("KRW-BTC", 100);      // 개수 에러
}


main()